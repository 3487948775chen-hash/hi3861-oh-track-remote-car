#define SSD1306_USE_I2C
#define SSD1306_INCLUDE_FONT_7x10
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include "iot_i2c.h"
#include <stdio.h>

// 修正：确保使用库中定义的颜色枚举，通常在 ssd1306.h 中定义
// 如果编译报错说 Black 未定义，请将其改为 Black (或者是 SSD1306_COLOR_BLACK)
#define OLED_COLOR_BLACK 0 
#define OLED_COLOR_WHITE 1

// 补充：OLED 初始化接口
void OLED_Init(void) {
    // 1. I2C 总线初始化 (根据Hi3861标准I2C0配置)
    hi_io_set_func(13, 6); // GPIO13 -> I2C0_SDA
    hi_io_set_func(14, 6); // GPIO14 -> I2C0_SCL
    IoTI2cInit(0, 400000); 

    // 2. 调用驱动库的初始化序列
    ssd1306_Init();
    
    // 3. 初始显示设置
    ssd1306_Fill(OLED_COLOR_BLACK);
    ssd1306_UpdateScreen();
    
    printf("OLED_Init success!\r\n");
}
void OLED_ShowStatus(const char* status, int speed) {
    char speed_str[16];
    sprintf(speed_str, "Speed: %d %%", speed);
    
    // 1. 清屏
    ssd1306_Fill(OLED_COLOR_BLACK);
    
    // 2. 显示 "State:"
    ssd1306_SetCursor(0, 0); 
    ssd1306_DrawString("State:", Font_7x10, OLED_COLOR_WHITE); 
    
    // 3. 显示具体状态值
    ssd1306_SetCursor(48, 0); 
    ssd1306_DrawString((char*)status, Font_7x10, OLED_COLOR_WHITE);
    
    // 4. 显示速度
    ssd1306_SetCursor(0, 20); 
    ssd1306_DrawString(speed_str, Font_7x10, OLED_COLOR_WHITE);
    
    // 5. 刷新屏幕 (重要)
    ssd1306_UpdateScreen();
}